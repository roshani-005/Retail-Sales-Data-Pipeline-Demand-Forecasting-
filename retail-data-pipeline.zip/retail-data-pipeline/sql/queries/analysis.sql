-- 1. Top 5 selling products by total revenue
SELECT product, SUM(sales) AS total_sales
FROM sales
GROUP BY product
ORDER BY total_sales DESC
LIMIT 5;

-- 2. Month-over-month sales growth by region (window function)
WITH monthly_sales AS (
    SELECT
        region,
        strftime('%Y-%m', date) AS month,
        SUM(sales) AS total_sales
    FROM sales
    GROUP BY region, month
)
SELECT
    region,
    month,
    total_sales,
    LAG(total_sales) OVER (PARTITION BY region ORDER BY month) AS prev_month_sales,
    ROUND(
        (total_sales - LAG(total_sales) OVER (PARTITION BY region ORDER BY month)) * 100.0
        / NULLIF(LAG(total_sales) OVER (PARTITION BY region ORDER BY month), 0), 2
    ) AS mom_growth_pct
FROM monthly_sales
ORDER BY region, month;

-- 3. Running total of sales per category (window function)
SELECT
    category,
    date,
    sales,
    SUM(sales) OVER (PARTITION BY category ORDER BY date) AS running_total
FROM sales
ORDER BY category, date;

-- 4. Rank products within each region by revenue (CTE + window function)
WITH product_region_sales AS (
    SELECT region, product, SUM(sales) AS total_sales
    FROM sales
    GROUP BY region, product
)
SELECT
    region,
    product,
    total_sales,
    RANK() OVER (PARTITION BY region ORDER BY total_sales DESC) AS rank_in_region
FROM product_region_sales
QUALIFY rank_in_region <= 3;  -- Note: QUALIFY not supported in SQLite; use subquery there

-- 5. Average order value by category
SELECT
    category,
    ROUND(AVG(sales), 2) AS avg_order_value,
    COUNT(*) AS order_count
FROM sales
GROUP BY category
ORDER BY avg_order_value DESC;
