import pandas as pd
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.transformation.transform import transform


def make_dummy_raw_csv(path):
    df = pd.DataFrame({
        "order_id": ["A1", "A1", "A2", "A3"],  # duplicate on purpose
        "date": ["2024-01-01", "2024-01-01", "2024-01-02", "not-a-date"],
        "region": ["North", "North", "South", "East"],
        "category": ["Grocery", "Grocery", "Apparel", "Toys"],
        "product": ["Bread", "Bread", "Shirt", "Blocks"],
        "quantity": [2, 2, None, 1],
        "unit_price": [10.0, 10.0, 20.0, None],
        "sales": [None, None, None, None],
    })
    df.to_csv(path, index=False)


def test_transform_cleans_data(tmp_path):
    raw_path = tmp_path / "raw.csv"
    processed_path = tmp_path / "processed.csv"
    make_dummy_raw_csv(raw_path)

    config_path = tmp_path / "config.yaml"
    config_path.write_text(f"""
paths:
  raw: "{raw_path}"
  processed: "{processed_path}"
database:
  path: "{tmp_path}/warehouse.db"
forecast:
  target_column: sales
  date_column: date
  horizon_days: 7
genai:
  model: claude-sonnet-4-6
  max_tokens: 1000
""")

    transform(str(raw_path), config_path=str(config_path))
    result = pd.read_csv(processed_path)

    # duplicate order_id A1 removed, malformed date row removed
    assert len(result) == 2
    assert "sales" in result.columns
    assert (result["sales"] > 0).all()
