# Retail Sales Data Pipeline & Demand Forecasting

An end-to-end data engineering project: ingests raw retail sales data,
cleans and loads it into a warehouse, runs analytical SQL, trains a
demand forecasting model, and exposes a natural-language query layer
on top using Claude.

## Architecture

```
Extract (extract.py)
      |
      v
Transform (transform.py)  --> cleans nulls, dedupes, fixes types
      |
      v
Load (load.py)  --> loads into SQLite warehouse (swap for Redshift/
      |               BigQuery/Synapse in a cloud deployment)
      v
SQL Analysis (sql/queries/analysis.sql)  --> CTEs, window functions
      |
      v
ML Forecasting (forecast_model.py)  --> XGBoost demand forecast
      |
      v
GenAI Layer (nl_query.py)  --> NL-to-SQL querying + auto summaries
      |
      v
Orchestration (pipeline/run_all.py)  --> chains every stage
```

## Tech Stack
- **Python**: pandas, SQLAlchemy, scikit-learn, XGBoost
- **SQL**: SQLite (swap connection string for a cloud warehouse)
- **GenAI**: Anthropic Claude API for NL-to-SQL and summarization
- **CI/CD**: GitHub Actions runs the test suite on every push
- **Testing**: pytest

## Setup

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY="your-key-here"   # only needed for the GenAI layer
```

## Run the pipeline

```bash
python pipeline/run_all.py
```

This generates raw data, cleans it, loads it into `data/warehouse/retail.db`,
and trains the forecasting model, printing MAE/RMSE.

## Run analytical SQL

```bash
sqlite3 data/warehouse/retail.db < sql/queries/analysis.sql
```

## Try the natural language query layer

```python
from src.genai.nl_query import ask

result = ask("What are the top 5 products by total sales?")
print(result)
```

## Run tests

```bash
pytest tests/ -v
```

## Notes on cloud deployment
This project uses SQLite locally for portability. In a cloud setup:
- Extraction would pull from a real API / S3 bucket instead of
  generating synthetic data
- Loading would target Redshift / BigQuery / Azure Synapse via the
  same SQLAlchemy interface
- Orchestration would move from a single script into an Airflow DAG
  with each stage as its own task

## What this project demonstrates
- Data engineering fundamentals: extract, transform, load
- SQL: window functions, CTEs, aggregate queries
- Cloud-ready architecture (swap-in warehouse connection)
- CI/CD: automated testing on push
- ML: time-series demand forecasting with XGBoost
- GenAI: LLM-powered natural language querying and auto-summarization
