"""
Transformation layer.

Cleans the raw feed: drops duplicates, handles nulls, fixes types,
and derives the `sales` column. This is the layer you'd point to in
an interview to talk through real data-quality decisions.
"""

import os
import pandas as pd
from src.utils.config import load_config
from src.utils.logger import get_logger

logger = get_logger(__name__)


def transform(raw_path: str, config_path: str = "config.yaml") -> str:
    config = load_config(config_path)
    processed_path = config["paths"]["processed"]

    logger.info(f"Reading raw data from {raw_path}")
    df = pd.read_csv(raw_path)
    initial_rows = len(df)

    # 1. Drop exact duplicate rows
    df = df.drop_duplicates(subset=["order_id"])

    # 2. Handle missing quantity -> assume 1 (median imputation would also be defensible)
    df["quantity"] = df["quantity"].fillna(df["quantity"].median())

    # 3. Drop rows with missing price (can't reliably impute a price)
    df = df.dropna(subset=["unit_price"])

    # 4. Fix types
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"])
    df["quantity"] = df["quantity"].astype(int)
    df["unit_price"] = df["unit_price"].astype(float)

    # 5. Derive sales = quantity * unit_price
    df["sales"] = (df["quantity"] * df["unit_price"]).round(2)

    # 6. Basic sanity filter — remove impossible values
    df = df[(df["quantity"] > 0) & (df["unit_price"] > 0)]

    df = df.sort_values("date").reset_index(drop=True)

    logger.info(f"Cleaned data: {initial_rows} -> {len(df)} rows")
    os.makedirs(os.path.dirname(processed_path), exist_ok=True)
    df.to_csv(processed_path, index=False)
    logger.info(f"Wrote cleaned data to {processed_path}")
    return processed_path


if __name__ == "__main__":
    from src.utils.config import load_config
    cfg = load_config()
    transform(cfg["paths"]["raw"])
