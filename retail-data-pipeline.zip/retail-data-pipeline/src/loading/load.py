"""
Loading layer.

Loads the cleaned CSV into a SQLite warehouse (stand-in for
Redshift/BigQuery/Synapse in a cloud deployment — swapping the
SQLAlchemy connection string is the only change needed to point this
at a real cloud warehouse).
"""

import os
import pandas as pd
from sqlalchemy import create_engine, text
from src.utils.config import load_config
from src.utils.logger import get_logger

logger = get_logger(__name__)


def get_engine(db_path: str):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    return create_engine(f"sqlite:///{db_path}")


def load(processed_path: str, config_path: str = "config.yaml"):
    config = load_config(config_path)
    db_path = config["database"]["path"]

    engine = get_engine(db_path)

    # Apply schema
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    schema_path = os.path.join(root, "sql", "schema.sql")
    with open(schema_path) as f:
        schema_sql = f.read()

    with engine.begin() as conn:
        for statement in schema_sql.split(";"):
            if statement.strip():
                conn.execute(text(statement))

    df = pd.read_csv(processed_path, parse_dates=["date"])
    df.to_sql("sales", engine, if_exists="replace", index=False)

    logger.info(f"Loaded {len(df)} rows into {db_path} (table: sales)")
    return db_path


if __name__ == "__main__":
    from src.utils.config import load_config
    cfg = load_config()
    load(cfg["paths"]["processed"])
