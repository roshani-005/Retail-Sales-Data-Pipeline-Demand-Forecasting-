"""
ML layer.

Trains a demand forecasting model on the warehouse data and predicts
sales for the next N days. Uses simple date-based features + XGBoost;
swap in Prophet or an LSTM here if you want a DL talking point too.
"""

import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
from xgboost import XGBRegressor

from src.utils.config import load_config
from src.utils.logger import get_logger

logger = get_logger(__name__)


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate to daily sales and engineer date-based features."""
    daily = df.groupby("date", as_index=False)["sales"].sum()
    daily["date"] = pd.to_datetime(daily["date"])
    daily = daily.sort_values("date")

    daily["day_of_week"] = daily["date"].dt.dayofweek
    daily["day_of_month"] = daily["date"].dt.day
    daily["month"] = daily["date"].dt.month
    daily["is_weekend"] = daily["day_of_week"].isin([5, 6]).astype(int)

    # lag features
    daily["sales_lag_1"] = daily["sales"].shift(1)
    daily["sales_lag_7"] = daily["sales"].shift(7)
    daily["sales_rolling_7"] = daily["sales"].rolling(7).mean()

    daily = daily.dropna().reset_index(drop=True)
    return daily


def train_and_evaluate(config_path: str = "config.yaml"):
    config = load_config(config_path)
    db_path = config["database"]["path"]
    horizon = config["forecast"]["horizon_days"]

    engine = create_engine(f"sqlite:///{db_path}")
    df = pd.read_sql("SELECT date, sales FROM sales", engine)

    features_df = build_features(df)

    feature_cols = [
        "day_of_week", "day_of_month", "month", "is_weekend",
        "sales_lag_1", "sales_lag_7", "sales_rolling_7"
    ]
    X = features_df[feature_cols]
    y = features_df["sales"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=False  # keep time order intact
    )

    model = XGBRegressor(
        n_estimators=200, max_depth=4, learning_rate=0.05, random_state=42
    )
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))

    logger.info(f"Model evaluation -> MAE: {mae:.2f}, RMSE: {rmse:.2f}")

    return model, features_df, {"mae": mae, "rmse": rmse}


if __name__ == "__main__":
    train_and_evaluate()
