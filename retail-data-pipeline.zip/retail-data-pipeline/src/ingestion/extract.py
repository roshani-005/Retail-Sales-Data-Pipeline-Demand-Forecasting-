"""
Extraction layer.

In a real deployment this would hit a REST API, a source database,
or an S3 bucket. Here we simulate a raw retail sales feed with some
intentional data quality issues (nulls, duplicates, bad types) so the
transformation layer has real work to do.
"""

import os
import random
import pandas as pd
from datetime import datetime, timedelta
from faker import Faker

from src.utils.config import load_config
from src.utils.logger import get_logger

logger = get_logger(__name__)
fake = Faker()

REGIONS = ["North", "South", "East", "West"]
CATEGORIES = ["Electronics", "Grocery", "Apparel", "Furniture", "Toys"]


def generate_raw_data(n_rows: int = 5000, start_date: str = "2023-01-01") -> pd.DataFrame:
    """Simulate raw sales records pulled from a source system."""
    start = datetime.strptime(start_date, "%Y-%m-%d")
    rows = []

    for i in range(n_rows):
        date = start + timedelta(days=random.randint(0, 500))
        row = {
            "order_id": f"ORD{i:06d}",
            "date": date.strftime("%Y-%m-%d"),
            "region": random.choice(REGIONS),
            "category": random.choice(CATEGORIES),
            "product": fake.word().title(),
            "quantity": random.choice([1, 2, 3, 4, 5, None]),  # nulls on purpose
            "unit_price": round(random.uniform(5, 500), 2),
            "sales": None,  # will be computed downstream on purpose (bad feed)
        }
        rows.append(row)

    df = pd.DataFrame(rows)

    # Inject duplicates and a few malformed rows, like a real messy source would have
    df = pd.concat([df, df.sample(50)], ignore_index=True)
    df.loc[df.sample(30).index, "unit_price"] = None

    return df


def extract(config_path: str = "config.yaml") -> str:
    config = load_config(config_path)
    raw_path = config["paths"]["raw"]

    logger.info("Extracting raw retail sales data...")
    df = generate_raw_data()

    os.makedirs(os.path.dirname(raw_path), exist_ok=True)
    df.to_csv(raw_path, index=False)
    logger.info(f"Wrote {len(df)} raw rows to {raw_path}")
    return raw_path


if __name__ == "__main__":
    extract()
