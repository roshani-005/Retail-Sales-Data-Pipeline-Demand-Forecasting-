import yaml
import os

def load_config(path="config.yaml"):
    """Load the YAML config file from the project root."""
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    full_path = os.path.join(root, path)
    with open(full_path, "r") as f:
        return yaml.safe_load(f)
