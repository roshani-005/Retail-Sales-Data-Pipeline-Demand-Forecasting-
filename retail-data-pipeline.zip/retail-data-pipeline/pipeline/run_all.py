"""
Orchestration layer.

Chains extract -> transform -> load -> train -> (optional) GenAI summary.
In production this logic would live inside an Airflow DAG with each
step as a task; here it's a single script so it can be run or
scheduled with cron for the project demo.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.ingestion.extract import extract
from src.transformation.transform import transform
from src.loading.load import load
from src.ml.forecast_model import train_and_evaluate
from src.utils.logger import get_logger

logger = get_logger("pipeline")


def run(use_genai_summary: bool = False):
    logger.info("=== Starting pipeline run ===")

    raw_path = extract()
    processed_path = transform(raw_path)
    load(processed_path)
    model, features_df, metrics = train_and_evaluate()

    logger.info(f"Pipeline complete. Model metrics: {metrics}")

    if use_genai_summary:
        from src.genai.nl_query import summarize_forecast
        summary = summarize_forecast(features_df[["sales"]], metrics)
        logger.info(f"GenAI summary:\n{summary}")

    logger.info("=== Pipeline run finished ===")


if __name__ == "__main__":
    run(use_genai_summary=False)
